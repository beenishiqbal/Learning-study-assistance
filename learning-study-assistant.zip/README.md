# Learning Study Assistant 🧠

A multi-agent AI system built with Python and Gradio to help you:
- Generate thoughtful questions
- Get detailed answers
- Summarize study notes

## Features

🧩 **Agent Architecture**  
🤖 Powered by GPT-4o-mini via OpenRouter  
🎓 Designed for students and educators

## Run Locally

```bash
pip install -r requirements.txt
python app.py
```

## Demo

Hosted with Gradio's public sharing link.

## Project Structure

```
learning-study-assistant/
├── agents/            # Modular agents
├── llm/               # LLM wrapper (OpenRouter)
├── app.py             # Gradio UI
├── requirements.txt
└── README.md
```
