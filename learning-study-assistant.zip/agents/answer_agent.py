from agents.base_agent import Agent

class AnswerAgent(Agent):
    def __init__(self, llm):
        self.llm = llm

    def run(self, text, questions):
        messages = [
            {"role": "system", "content": "You are an expert tutor who provides detailed answers."},
            {"role": "user", "content": f"Given the text:\n{text}\n\nAnswer these questions:\n{questions}"}
        ]
        return self.llm.call(messages)
