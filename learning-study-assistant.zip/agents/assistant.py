from agents.question_agent import QuestionGenerationAgent
from agents.answer_agent import AnswerAgent
from agents.summary_agent import SummaryAgent

class LearningStudyAssistant:
    def __init__(self, llm):
        self.question_agent = QuestionGenerationAgent(llm)
        self.answer_agent = AnswerAgent(llm)
        self.summary_agent = SummaryAgent(llm)

    def run(self, text):
        questions = self.question_agent.run(text).strip()
        answers = self.answer_agent.run(text, questions).strip()
        summary = self.summary_agent.run(text).strip()

        return {
            "questions": questions,
            "answers": answers,
            "summary": summary
        }
