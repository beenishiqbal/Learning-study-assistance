from agents.base_agent import Agent

class QuestionGenerationAgent(Agent):
    def __init__(self, llm):
        self.llm = llm

    def run(self, text):
        messages = [
            {"role": "system", "content": "You are a helpful assistant who generates thoughtful questions."},
            {"role": "user", "content": f"Create 5 thoughtful questions based on the following text:\n\n{text}"}
        ]
        return self.llm.call(messages)
