from agents.base_agent import Agent

class SummaryAgent(Agent):
    def __init__(self, llm):
        self.llm = llm

    def run(self, text):
        messages = [
            {"role": "system", "content": "You are a concise summarizer."},
            {"role": "user", "content": f"Summarize the following text:\n\n{text}"}
        ]
        return self.llm.call(messages)
