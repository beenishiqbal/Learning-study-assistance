import gradio as gr
from llm.openrouter_llm import OpenRouterLLM
from agents.assistant import LearningStudyAssistant

API_KEY = "your_openrouter_api_key_here"
llm = OpenRouterLLM(API_KEY)
assistant = LearningStudyAssistant(llm)

def process_notes(notes):
    results = assistant.run(notes)
    return results["questions"], results["answers"], results["summary"]

iface = gr.Interface(
    fn=process_notes,
    inputs=gr.Textbox(label="Enter your biology notes", lines=15, placeholder="Paste your biology notes here..."),
    outputs=[
        gr.Textbox(label="Generated Questions"),
        gr.Textbox(label="Generated Answers"),
        gr.Textbox(label="Summary"),
    ],
    title="Biology Notes Analyzer",
    description="This tool generates questions, answers, and a summary from your biology notes."
)

if __name__ == "__main__":
    iface.launch(share=True)
